import 'package:flutter/material.dart';
// Example import paths – adjust to your actual structure:


import '../widgets/add_to_cart_button.dart';
import '../widgets/customization_chips.dart';
import '../widgets/food_addon_checkbox.dart';
import '../widgets/food_image_banner.dart';
import '../widgets/food_tags_wrap.dart';
import '../widgets/info_icon_text_row.dart';
import '../widgets/price_row.dart';
import '../widgets/quantity_selector.dart';
import '../widgets/rating_row.dart';
import '../widgets/section_title.dart';
import '../widgets/vendor_info_row.dart';

class FoodDetailScreen extends StatefulWidget {
  final String foodId;
  const FoodDetailScreen({required this.foodId, super.key});

  @override
  State<FoodDetailScreen> createState() => _FoodDetailScreenState();
}

class _FoodDetailScreenState extends State<FoodDetailScreen> {
  // Mock data (replace with real data or ViewModel as needed)
  int quantity = 1;
  String selectedSize = 'Regular';
  bool extraCheese = false;
  double originalPrice = 24.99;
  double discountPercent = 20.0;
  final List<String> foodTags = ['Halal', 'Organic', 'Gluten-Free', '🌶️ Medium Spicy'];
  final List<String> customizationOptions = ['No onions', 'Well-done', 'Extra spice'];
  final List<Map<String, dynamic>> reviews = [
    {
      'name': 'Amelia W.',
      'comment': 'Absolutely divine! Perfect texture.',
      'rating': 5.0,
    },
    {
      'name': 'Lucas M.',
      'comment': 'Flavors were excellent, will reorder.',
      'rating': 4.5,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final discountedPrice = originalPrice * (1 - discountPercent / 100);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Deluxe Cuisine'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Food image with label
            const FoodImageBanner(
              imageUrl: 'https://images.unsplash.com/photo-1600891964599-f61ba0e24092',
            ),
            // Vendor Row
            VendorInfoRow(
              vendorImage: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5',
              vendorName: 'Gourmet Bistro',
              vendorLocation: 'Downtown Branch',
              rating: 4.9,
              reviewsCount: 320,
              onViewRestaurant: () {
                // TODO: Navigate to restaurant screen
              },
              padding: EdgeInsets.all(16), // Optional!
            ),

            // Main food info and price
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, -4),
                  )
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionTitle('Grilled Chicken Salad', fontSize: 28),
                  const SizedBox(height: 8),
                  Text('Category: Main Course', style: TextStyle(color: Colors.grey[600])),
                  const SizedBox(height: 8),
                  RatingRow(rating: 4.8, reviewsCount: 142, iconSize: 24),
                  const SizedBox(height: 8),
                  PriceRow(
                    originalPrice: originalPrice,
                    discountedPrice: discountedPrice,
                    discountPercent: discountPercent,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Enjoy a rich blend of seasoned grilled chicken, arugula, baby greens, and a gourmet vinaigrette.',
                    style: const TextStyle(fontSize: 16, height: 1.5),
                  ),
                  const SizedBox(height: 16),
                  InfoIconTextRow(icon: Icons.eco, text: 'Ingredients: Chicken, Arugula, Greens, Vinaigrette'),
                  const SizedBox(height: 8),
                  InfoIconTextRow(icon: Icons.warning_amber_rounded, text: 'Allergens: 🥜 🌾 🥛'),
                  const SizedBox(height: 8),
                  FoodTagsWrap(tags: foodTags),
                  const SizedBox(height: 16),

                  // Size options
                  const SectionTitle('Size Options:', fontSize: 16),
                  DropdownButton<String>(
                    value: selectedSize,
                    onChanged: (String? newValue) {
                      setState(() {
                        selectedSize = newValue!;
                      });
                    },
                    items: <String>['Regular', 'Large', 'Family']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 12),

                  // Add-ons (e.g. cheese)
                  const SectionTitle('Add-ons:', fontSize: 16),
                  FoodAddonCheckbox(
                    title: 'Add extra cheese - \$1.00',
                    value: extraCheese,
                    onChanged: (val) {
                      setState(() {
                        extraCheese = val ?? false;
                      });
                    },
                  ),
                  const SizedBox(height: 12),

                  // Customization
                  const SectionTitle('Customization:', fontSize: 16),
                  CustomizationChips(options: customizationOptions),
                  const SizedBox(height: 16),

                  // Delivery info
                  InfoIconTextRow(icon: Icons.delivery_dining, text: 'Delivery in 30–45 min • \$3.99 fee'),
                  const SizedBox(height: 4),
                  InfoIconTextRow(icon: Icons.schedule, text: 'Preparation Time: 15–20 minutes'),

                  const SizedBox(height: 16),

                  // Quantity selector
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Quantity', style: TextStyle(fontSize: 16)),
                      QuantitySelector(
                        quantity: quantity,
                        onIncrement: () {
                          setState(() => quantity++);
                        },
                        onDecrement: () {
                          setState(() {
                            if (quantity > 1) quantity--;
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Reviews
                  const SectionTitle('Customer Reviews', fontSize: 18),
                  const SizedBox(height: 16),
                  ...reviews.map((r) => Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundColor: Colors.brown.shade100,
                          child: Text(r['name'][0], style: const TextStyle(color: Colors.brown)),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(r['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
                              Row(
                                children: [
                                  Icon(Icons.star, color: Colors.amber, size: 16),
                                  const SizedBox(width: 2),
                                  Text('${r['rating']}', style: const TextStyle(fontSize: 12)),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(r['comment']),
                            ],
                          ),
                        )
                      ],
                    ),
                  )),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: AddToCartButton(
          total: discountedPrice * quantity + (extraCheese ? 1 : 0),
          enabled: true,
          onTap: () {
            // TODO: Implement add to cart logic
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Added to cart!')),
            );
          },
        ),
      ),
    );
  }
}
