// features/auth/data/mappers/user_profile_mappers.dart
import 'package:restaurant_marketplace/features/profile/domain/entities/user_profile.dart';

Map<String, dynamic> userProfileToFirestore(UserProfile p) => {
  'id': p.id,
  'firstName': p.firstName,
  'lastName': p.lastName,
  'contactNumber': p.contactNumber,
  'email': p.email,
  'avatarUrl': p.avatarUrl,
  'addressRefs': p.addressRefs.map((e) => e.toJson()).toList(),
  'walletRef': p.walletRef?.toJson(),
  'reservationRefs': p.reservationRefs.map((e) => e.toJson()).toList(),
  'paymentMethodRefs': p.paymentMethodRefs.map((e) => e.toJson()).toList(),
  'orderRefs': p.orderRefs.map((e) => e.toJson()).toList(),
  'favoriteRefs': p.favoriteRefs.map((e) => e.toJson()).toList(),
  'discountRefs': p.discountRefs.map((e) => e.toJson()).toList(),
  'isEmailVerified': p.isEmailVerified,
  'isPhoneVerified': p.isPhoneVerified,
  'createdAt': p.createdAt,
  'updatedAt': p.updatedAt,
  'roleMetadata': p.roleMetadata,
};

UserProfile firestoreToUserProfile(Map<String, dynamic> json) => UserProfile(
  id: json['id'] as String,
  firstName: json['firstName'] as String,
  lastName: json['lastName'] as String,
  contactNumber: json['contactNumber'] as String,
  email: json['email'] as String?,
  avatarUrl: json['avatarUrl'] as String?,
  addressRefs: const <dynamic>[], // fill if you persist them; keeping lean for now
  walletRef: null,
  reservationRefs: const <dynamic>[],
  paymentMethodRefs: const <dynamic>[],
  orderRefs: const <dynamic>[],
  favoriteRefs: const <dynamic>[],
  discountRefs: const <dynamic>[],
  isEmailVerified: (json['isEmailVerified'] as bool?) ?? false,
  isPhoneVerified: (json['isPhoneVerified'] as bool?) ?? false,
  createdAt: (json['createdAt'] as DateTime?),
  updatedAt: (json['updatedAt'] as DateTime?),
  roleMetadata: (json['roleMetadata'] as Map<String, dynamic>?) ?? const {},
);
