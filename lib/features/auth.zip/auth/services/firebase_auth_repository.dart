import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final firebaseAuthProvider = Provider<FirebaseAuth>((_) => FirebaseAuth.instance);
final firestoreProvider = Provider<FirebaseFirestore>((_) => FirebaseFirestore.instance);

final authRepoProvider = Provider<FirebaseAuthRepository>((ref) {
  return FirebaseAuthRepository(
    ref.read(firebaseAuthProvider),
    ref.read(firestoreProvider),
  );
});

class FirebaseAuthRepository {
  final FirebaseAuth _auth;
  final FirebaseFirestore _db;
  const FirebaseAuthRepository(this._auth, this._db);

  /// Creates an account:
  /// - If email provided -> email/password user
  /// - Else -> anonymous user
  /// Then writes a profile doc to Firestore at `user_profiles/{uid}`.
  Future<UserCredential> signUpAndCreateProfile({
    required String firstName,
    required String lastName,
    required String phoneNumber,
    String? email, // optional
    required String password, // required for the email flow; ignored if anonymous
  }) async {
    late UserCredential cred;

    if (email != null && email.trim().isNotEmpty) {
      cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      // Send verification email (optional)
      if (!cred.user!.emailVerified) {
        await cred.user!.sendEmailVerification();
      }
    } else {
      // Email not provided -> anonymous account
      cred = await _auth.signInAnonymously();
    }

    final uid = cred.user!.uid;

    // Create/merge profile in Firestore
    final profileDoc = _db.collection('user_profiles').doc(uid);
    await profileDoc.set({
      'id': uid,
      'firstName': firstName.trim(),
      'lastName': lastName.trim(),
      'contactNumber': phoneNumber.trim(),
      'email': (email?.trim().isEmpty ?? true) ? null : email!.trim(),
      'avatarUrl': null,
      'addressRefs': <Map<String, dynamic>>[],
      'walletRef': null,
      'reservationRefs': <Map<String, dynamic>>[],
      'paymentMethodRefs': <Map<String, dynamic>>[],
      'orderRefs': <Map<String, dynamic>>[],
      'favoriteRefs': <Map<String, dynamic>>[],
      'discountRefs': <Map<String, dynamic>>[],
      'isEmailVerified': cred.user!.emailVerified,
      'isPhoneVerified': false, // set true if you add phone verification later
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'roleMetadata': <String, dynamic>{},
    }, SetOptions(merge: true));

    return cred;
  }

  /// Later: link email/password to an anonymous account.
  Future<void> linkEmailPasswordToCurrentUser({
    required String email,
    required String password,
  }) async {
    final user = _auth.currentUser;
    if (user == null) throw FirebaseAuthException(code: 'no-current-user', message: 'No user');
    final cred = EmailAuthProvider.credential(email: email.trim(), password: password);
    await user.linkWithCredential(cred);
    await user.sendEmailVerification();
  }

  String mapErrorToMessage(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'An account already exists for that email.';
      case 'invalid-email':
        return 'That email address looks invalid.';
      case 'weak-password':
        return 'That password is too weak. Try a longer one.';
      case 'operation-not-allowed':
        return 'Email/password sign-up is disabled. Contact support.';
      case 'network-request-failed':
        return 'Network error. Check your connection and try again.';
      case 'too-many-requests':
        return 'Too many attempts. Please wait a moment and try again.';
      default:
        return 'Could not create your account. (${e.code})';
    }
  }
}
