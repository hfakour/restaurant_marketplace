import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../domain/usecase/register_with_email.dart';
import 'auth_signup_state.dart';

class AuthSignUpCubit extends Cubit<AuthSignUpState> {
  AuthSignUpCubit(this._read) : super(const AuthSignUpState.idle());
  final Reader _read;

  Future<void> submit({
    required String firstName,
    required String lastName,
    required String phone,
    String? email,
    required String password,
  }) async {
    emit(const AuthSignUpState.submitting());
    try {
      await _read(registerWithEmailUC).call(
        firstName: firstName,
        lastName: lastName,
        phoneNumber: phone,
        email: email,
        password: password,
      );
      emit(const AuthSignUpState.success());
    } catch (e) {
      emit(AuthSignUpState.error('Could not create your account.'));
    }
  }
}
