import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/repository/auth_repository_impl.dart';
import '../repositories/auth_repository.dart';
import '../entities/auth_entities.dart';

final registerWithEmailUC = Provider.autoDispose((ref) =>
    RegisterWithEmailUseCase(ref.read));

class RegisterWithEmailUseCase {
  RegisterWithEmailUseCase(this._read);
  final Reader _read;

  Future<AuthAccount> call({
    required String firstName,
    required String lastName,
    required String phoneNumber,
    String? email,
    required String password,
  }) {
    return _read(authRepositoryProvider).registerWithEmail(
      firstName: firstName,
      lastName: lastName,
      phoneNumber: phoneNumber,
      email: email,
      password: password,
    );
  }
}
