import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/repository/auth_repository_impl.dart';
import '../repositories/auth_repository.dart';
import '../entities/auth_entities.dart';

final loginWithEmailUC = Provider.autoDispose((ref) => LoginWithEmailUseCase(ref.read));

class LoginWithEmailUseCase {
  LoginWithEmailUseCase(this._read);
  final Reader _read;

  Future<AuthAccount> call({
    required String email,
    required String password,
  }) {
    return _read(authRepositoryProvider).loginWithEmail(email: email, password: password);
  }
}
